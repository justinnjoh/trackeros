<?php
// post model

class Error_Model extends Base_model {

  public function index () { 
  	$this->get_menu();
  }


}

?>
